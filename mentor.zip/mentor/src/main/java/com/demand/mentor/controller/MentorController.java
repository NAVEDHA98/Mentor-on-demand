package com.demand.mentor.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.demand.mentor.model.Login;
import com.demand.mentor.model.Mentor;
import com.demand.mentor.service.LoginService;
import com.demand.mentor.service.MentorService;

@Controller
public class MentorController 
{
	@Autowired
	LoginService loginService;
	
	@Autowired
	MentorService mentorService;
	
	@RequestMapping(path="mentorRegistrationProcess", method = RequestMethod.POST)
	public ModelAndView insertUser(Mentor mentor)
	{
		ModelAndView mav = null;
		
		Mentor insertResult = null;
		Login loginCredential = null;
		
		insertResult = mentorService.insertMentor(mentor);
		loginCredential = loginService.insertLoginDetails(mentor);
		
		if(insertResult != null && loginCredential != null)
		{	
			System.out.println(insertResult);
			mav = new ModelAndView("HomePage", "message", "Record Inserted");
		}
		else
		{
			mav = new ModelAndView("Register", "message", "Record Not Inserted");
		}
		return mav;
	}
}
