package com.demand.mentor.service;

import com.demand.mentor.model.Admin;

public interface AdminService {
	public Admin getAdminDetails(String name);
}
