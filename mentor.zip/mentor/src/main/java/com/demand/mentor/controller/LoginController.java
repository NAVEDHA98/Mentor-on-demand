package com.demand.mentor.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.demand.mentor.model.Login;
import com.demand.mentor.model.LoginPojo;
import com.demand.mentor.service.AdminService;
import com.demand.mentor.service.LoginService;
import com.demand.mentor.service.MentorService;
import com.demand.mentor.service.UserService;

@Controller
public class LoginController 
{
	@Autowired
	LoginService loginService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	MentorService mentorService;
	
	@Autowired
	AdminService adminService;
	
	@RequestMapping(path="userLoginProcess", method = RequestMethod.POST)
	public ModelAndView userLoginProcess(HttpServletRequest request, LoginPojo loginPojo)
	{
		ModelAndView mav = null;
		
		List<Login> loginDetails = loginService.getAllLoginDetails();
		
		HttpSession session = request.getSession(); 
		
		int flag = 0;
		
		for(Login login:loginDetails)
		{
			if(loginPojo.getUserName().equals(login.getUserName()) && loginPojo.getPassword().equals(login.getPassword()))
			{
				if(login.getUserType().equals("user"))
				{
					if(login.getStatus().equals("blocked"))
					{
						mav = new ModelAndView("SignIn", "message", "Your account is blocked");
					}
					else
					{
						session.setAttribute("userDetails", userService.getUserDetails(login.getUserName()));
						mav = new ModelAndView("UserLandingPage");
					}
				}
				else if(login.getUserType().equals("mentor"))
				{
					if(login.getStatus().equals("blocked"))
					{
						mav = new ModelAndView("SignIn", "message", "Your account is blocked");
					}
					else
					{
						session.setAttribute("mentorDetails", mentorService.getMentorDetails(login.getUserName()));
						mav = new ModelAndView("MentorLandingPage");
					}
				}
				else
				{
					session.setAttribute("adminDetails", adminService.getAdminDetails(login.getUserName()));
					mav = new ModelAndView("AdminLandingPage");
				}
				flag = 1;
			}
		}
		if( flag == 0 )
			mav = new ModelAndView("SignIn", "message", "Invalid UserName and Password");
		return mav;
	}
}
