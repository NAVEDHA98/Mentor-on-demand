package com.demand.mentor.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.demand.mentor.model.Login;
import com.demand.mentor.model.Mentor;
import com.demand.mentor.model.User;
import com.demand.mentor.service.LoginService;
import com.demand.mentor.service.MentorService;
import com.demand.mentor.service.UserService;


@Controller
public class UserController 
{
	@Autowired
	UserService userService;
	
	@Autowired
	LoginService loginService;
	
	@Autowired 
	MentorService mentorService;

	@RequestMapping(path="userRegistrationProcess", method = RequestMethod.POST)
	public ModelAndView insertUser(User user)
	{
		ModelAndView mav = null;
		
		User insertResult = null;
		Login loginCredential = null;
		
		insertResult = userService.insertUser(user);
		loginCredential = loginService.insertLoginDetails(user);
		
		if(insertResult != null && loginCredential != null)
		{	
			System.out.println(insertResult);
			mav = new ModelAndView("HomePage", "message", "Record Inserted");
		}
		else
		{
			mav = new ModelAndView("Register", "message", "Record Not Inserted");
		}
		return mav;
	}
	
	@RequestMapping(path="/searchMentor", method = { RequestMethod.POST, RequestMethod.GET } )
	public ModelAndView searchMentor(@RequestParam("technology") String technology, HttpServletRequest request)
	{
		ModelAndView mav =null;
		   
	   HttpSession session = request.getSession(false);
	   User user = (User) session.getAttribute("userDetails");
	   
	   List<Mentor> mentorSearchDetails = null;
	   
	   if(user != null)
	   {
		   mentorSearchDetails = mentorService.getSearchMentor(technology);
	    	  
    	  session.setAttribute("mentorSearchDetails",mentorSearchDetails);
    
    	  mav = new ModelAndView("SearchTechnology");
	   }
	   else
	  {
		  mav = new ModelAndView("HomePage");
	  }
	   return mav;
	}
	
	  @RequestMapping(value = "/logoutUser", method = RequestMethod.POST)
	  public ModelAndView logoutAdmin(HttpServletRequest request) throws IOException
	  {
		   ModelAndView mav =null;
		   
		   HttpSession session = request.getSession(false);
		   User user = (User) session.getAttribute("userDetails");
		   
		   session.invalidate();
		   
		   mav = new ModelAndView("HomePage");
		   
		   return mav;
	  }
}
