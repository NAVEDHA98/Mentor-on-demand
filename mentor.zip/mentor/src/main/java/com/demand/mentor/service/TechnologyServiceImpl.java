package com.demand.mentor.service;

import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demand.mentor.controller.TechnologyDao;
import com.demand.mentor.model.Technology;

@Service
public class TechnologyServiceImpl implements TechnologyService{
	@Autowired
	TechnologyDao technologyDao;
	public List<Technology> getAlltechnology() 
	{
			return technologyDao.findAll();
	}

	public int addTechnology(Technology technology) {
		technologyDao.save(technology);
		return 1;
	}
}
