package com.demand.mentor.service;

import java.util.List;

import com.demand.mentor.model.Technology;

public interface TechnologyService {

	public List<Technology> getAlltechnology() ;

	public int addTechnology(Technology technology);

}
