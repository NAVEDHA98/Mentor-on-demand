package com.demand.mentor.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demand.mentor.dao.LoginDao;
import com.demand.mentor.model.Login;
import com.demand.mentor.model.Mentor;
import com.demand.mentor.model.User;

@Service
public class LoginServiceImpl implements LoginService
{
	@Autowired
	LoginDao loginDao;
	
	public List<Login> getAllLoginDetails() {
		return loginDao.findAll();
	}

	public Login insertLoginDetails(User user) {
		Login login = new Login(user);
		return loginDao.save(login);
	}
	
	public Login insertLoginDetails(Mentor mentor) {
		Login login = new Login(mentor);
		return loginDao.save(login);
	}
}
