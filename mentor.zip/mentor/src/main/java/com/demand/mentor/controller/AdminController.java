package com.demand.mentor.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.demand.mentor.model.Admin;
import com.demand.mentor.model.Mentor;
import com.demand.mentor.model.Technology;
import com.demand.mentor.model.User;
import com.demand.mentor.service.MentorService;
import com.demand.mentor.service.TechnologyService;
import com.demand.mentor.service.UserService;

@Controller
public class AdminController 
{
	  @Autowired
	  TechnologyService technologyService;
	  
	  @Autowired
	  UserService userService;
	  
	  @Autowired 
	  MentorService mentorService;
      
	  @RequestMapping(path="/technologies", method = { RequestMethod.POST, RequestMethod.GET } )
      public ModelAndView technologies(ModelMap model, HttpServletRequest request)
      {
    	  ModelAndView mav = null;
    	  
		  List<Technology> technologies = null;
		  
		  HttpSession session = request.getSession(false);
		  Admin admin = (Admin) session.getAttribute("adminDetails");
		  
		  if(admin != null)
    	  {
			  technologies = technologyService.getAlltechnology();
			  
			  session.setAttribute("technologies",technologies);
	    
	    	  mav = new ModelAndView("AdminTechnologyList");
    	  }
		  else
		  {
			  mav = new ModelAndView("HomePage");
		  }
    	  return mav;
      }
	  
	  @RequestMapping(path="/addTechnology", method = { RequestMethod.POST, RequestMethod.GET })
	  public ModelAndView addTechnology(@ModelAttribute("command") Technology technology, HttpServletRequest request)
	  {
		  ModelAndView mav = null;
		  int recordInserted = 0;
		  List<Technology> technologies = null;
		  
		  HttpSession session = request.getSession(false);
		  Admin admin = (Admin) session.getAttribute("adminDetails");
		  
		  if(admin != null)
		  {
			  recordInserted = technologyService.addTechnology(technology);
			  
			  if(recordInserted == 1)
			  {
				  technologies = technologyService.getAlltechnology();
		    	  session.setAttribute("technologies",technologies);
		    	  
		    	  mav = new ModelAndView("AdminTechnologyList");
			  }
			  else
			  {
				  mav = new ModelAndView("AdminTechnologyList", "message", "Record not Inserted");
			  }
		  }
		  else
		  {
			  mav = new ModelAndView("HomePage");
		  }
		  return mav;
	  }
	  
	  @RequestMapping(path="/userBlockPage", method = { RequestMethod.POST, RequestMethod.GET } )
      public ModelAndView userBlockPage(HttpServletRequest request)
      {
    	  ModelAndView mav = null;
    	  
		  List<User> userUnblockedDetails = null;
		  
		  HttpSession session = request.getSession(false);
		  Admin admin = (Admin) session.getAttribute("adminDetails");
		  
		  if(admin != null)
		  {
			  userUnblockedDetails = userService.getAllUnblockedUser("unblocked");
	    	  
	    	  session.setAttribute("userUnblockedDetails",userUnblockedDetails);
	    
	    	  mav = new ModelAndView("UserBlockPage");
		  }
		  else
		  {
			  mav = new ModelAndView("HomePage");
		  }
    	  return mav;
      }
	  
	  @RequestMapping(value = "/blockUser", method = { RequestMethod.POST, RequestMethod.GET })
	  public ModelAndView blockUser(HttpServletRequest request)
	  {
		  ModelAndView mav = null;
		  int block = 0;
		  int userId=0;
		  List<User> userUnblockedDetails = null;
		  
		  String id = request.getParameter("userId");
		  if(id != null)
		  {
			  userId = Integer.parseInt(id);
		  }

		  HttpSession session = request.getSession(false);
		  Admin admin = (Admin) session.getAttribute("adminDetails");
		  
		  if(admin != null)
		  {
			   block = userService.blockUser(userId);
			   if(block == 1)
			   {
				   userUnblockedDetails = userService.getAllUnblockedUser("unblocked");
			    	  
			       session.setAttribute("userDetails",userUnblockedDetails);
			    
			       mav = new ModelAndView("UserBlockPage");
			   }
			   else
			   {
				   mav = new ModelAndView("UserBlockPage", "message", "User not Blocked");
			   }
		  }
		  else
		  {
			  mav = new ModelAndView("HomePage");
		  }
		  return mav;
	  }
	  
	  @RequestMapping(path="/mentorBlockPage", method = { RequestMethod.POST, RequestMethod.GET } )
      public ModelAndView mentorBlockPage(HttpServletRequest request)
      {
    	  ModelAndView mav = null;
    	  
		  List<Mentor> mentorUnblockedDetails = null;
		  
		  HttpSession session = request.getSession(false);
		  Admin admin = (Admin) session.getAttribute("adminDetails");
		  
		  if(admin != null)
		  {
			  mentorUnblockedDetails = mentorService.getAllUnblockedMentor("unblocked");
	    	  
	    	  session.setAttribute("mentorUnblockedDetails",mentorUnblockedDetails);
	    
	    	  mav = new ModelAndView("MentorBlockPage");
		  }
		  else
		  {
			  mav = new ModelAndView("HomePage");
		  }
    	  return mav;
      }
	  
	  @RequestMapping(value = "/blockMentor", method = { RequestMethod.POST, RequestMethod.GET })
	  public ModelAndView blockMentor(HttpServletRequest request)
	  {
		  ModelAndView mav = null;
		  int block = 0;
		  int mentorId=0;
		  List<Mentor> mentorUnblockedDetails = null;
		  
		  String id = request.getParameter("mentorId");
		  if(id != null)
		  {
			  mentorId = Integer.parseInt(id);
		  }

		  HttpSession session = request.getSession(false);
		  Admin admin = (Admin) session.getAttribute("adminDetails");
		  
		  if(admin != null)
		  {
			   block = mentorService.blockMentor(mentorId);
			   if(block == 1)
			   {
				   mentorUnblockedDetails = mentorService.getAllUnblockedMentor("unblocked");
			    	  
			       session.setAttribute("mentorUnblockedDetails",mentorUnblockedDetails);
			    
			       mav = new ModelAndView("MentorBlockPage");
			   }
			   else
			   {
				   mav = new ModelAndView("MentorBlockPage", "message", " Mentor not Blocked");
			   }
		  }
		  else
		  {
			  mav = new ModelAndView("HomePage");
		  }
		  return mav;
	  }
	  
	  @RequestMapping(value = "/browseHistory", method = { RequestMethod.POST, RequestMethod.GET })
	  public ModelAndView browseHistory(HttpServletRequest request)
	  {
		  ModelAndView mav = null;
		  
		  HttpSession session = request.getSession(false);
		  Admin admin = (Admin) session.getAttribute("adminDetails");
		  
		  if(admin != null)
		  {
			  mav = new ModelAndView("PaymentHistoryPage");
		  }
		  else
		  {
			  mav = new ModelAndView("HomePage");
		  }
		  return mav;
	  }
	  
	  @RequestMapping(value = "/logoutAdmin", method = RequestMethod.POST)
	  public ModelAndView logoutAdmin(HttpServletRequest request) throws IOException
	  {
		   ModelAndView mav =null;
		   
		   HttpSession session = request.getSession(false);
		    
		   session.invalidate();
		   
		   mav = new ModelAndView("HomePage");
		   
		   return mav;
	  }
}
