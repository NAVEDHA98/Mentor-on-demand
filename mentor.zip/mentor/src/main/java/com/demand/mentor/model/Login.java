package com.demand.mentor.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "login")
public class Login 
{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="login_id")
    private int loginId;
    
    @Column(name="username")
	private String userName;
    
    @Column(name = "password")
    private String password;
    
    @Column(name = "user_type")
	private String userType;
	
	@Column(name = "status")
	private String status;

	public int getLoginId() {
		return loginId;
	}
	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
    
	public Login()
	{
		
	}
	
	public Login(int loginId, String userName, String password, String userType, String status) {
		super();
		this.loginId = loginId;
		this.userName = userName;
		this.password = password;
		this.userType = userType;
		this.status = status;
	}
	
	public Login(Mentor mentor)
	{
		this.userName = mentor.getEmailId();
		this.password = mentor.getPassword();
		this.status = mentor.getStatus();
		this.userType = mentor.getRole();
		// TODO Auto-generated constructor stub
	}

	public Login(User user) {
		this.userName=user.getEmailId();
		this.password=user.getPassword();
		this.status = user.getStatus();
		this.userType = user.getRole();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Login [loginId=" + loginId + ", userName=" + userName + ", password=" + password + ", userType="
				+ userType + ", status=" + status + "]";
	}
}
