package com.demand.mentor.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.demand.mentor.model.LoginPojo;
import com.demand.mentor.model.Mentor;
import com.demand.mentor.model.User;

@Controller
public class HomeController 
{
     @RequestMapping("/")
     public ModelAndView homePage()
     {
    	 return new ModelAndView("HomePage");
     }
     
    @RequestMapping(path="userLogin", method = RequestMethod.GET)
 	public String userLogin(Model model)
 	{
 		LoginPojo loginPojo = new LoginPojo();
 		model.addAttribute("loginPojo", loginPojo);
 		return "SignIn";
 	}
    
    @RequestMapping(path="registerPage")
    public ModelAndView registerPage()
    {
    	return new ModelAndView("RegisterPage");
    }
    
    @RequestMapping(path="userRegister", method = RequestMethod.GET)
 	public String userRegister(Model model)
 	{
 		User user = new User();
 		model.addAttribute("user", user);
 		return "UserRegister";
 	}
    
    @RequestMapping(path="mentorRegister", method = RequestMethod.GET)
 	public String mentorRegister(Model model)
 	{
 		Mentor mentor = new Mentor();
 		model.addAttribute("mentor", mentor);
 		return "MentorRegister";
 	}
}
