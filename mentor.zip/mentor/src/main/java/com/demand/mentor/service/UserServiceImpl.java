package com.demand.mentor.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demand.mentor.dao.LoginDao;
import com.demand.mentor.dao.UserDao;
import com.demand.mentor.model.Login;
import com.demand.mentor.model.User;

@Service
public class UserServiceImpl implements UserService
{
	@Autowired
	UserDao userDao;
	
	@Autowired
	LoginDao loginDao;
	
	public User insertUser(User user) {
		return userDao.save(user);
	}

	public List<User> getAllUserDetails() {
		return userDao.findAll();
	}

	public User getUserDetails(String name) {	
		return userDao.findByEmailId(name);
	}

	public List<User> getAllUnblockedUser(String status) {
		return userDao.findByStatus(status);
	}

	public int blockUser(int userId) {
		userDao.setUserStatus(userId);
		User user = userDao.findByUserId(userId);
		
		Login login = loginDao.findByUserName(user.getEmailId());
		int loginId = login.getLoginId();
		loginDao.setLoginStatus(loginId);
		return 1;
	}
}
