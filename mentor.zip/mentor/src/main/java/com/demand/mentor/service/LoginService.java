package com.demand.mentor.service;

import java.util.List;

import com.demand.mentor.model.Login;
import com.demand.mentor.model.Mentor;
import com.demand.mentor.model.User;

public interface LoginService {

	public List<Login> getAllLoginDetails();

	public Login insertLoginDetails(User user);

	public Login insertLoginDetails(Mentor mentor);

}
